﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12_Login___Register_Form
{
    public class Identity
    {
        public string identity = 
            "Nama         : Ramadian\n" +
            "Kelas          : X RPL I\n" +
            "No. Absen  : 22";
        public string getIdentity()
        { 
            return identity;
        }
    }
}
